import TeslaNewsTimeline from './TeslaNewsTimeline'

function App() {
  return <TeslaNewsTimeline />
}

export default App
